<?php

return array(
    'name'        => 'Грастин',
    'description' => 'Плагин службы доставки Грастин',
    'icon'        => 'img/grastin16.png',
    'logo'        => 'img/grastin.png',
    'version'     => '1.0',
    'locale'      => array('ru_RU'),
    'external'    => true,
    'vendor'      => 1100677,
);
