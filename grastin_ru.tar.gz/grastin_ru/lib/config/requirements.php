<?php
return array(
    'php.curl'               => array(
        'description' => 'Grastin REST API access',
        'strict'      => false,
    ),
    'phpini.allow_url_fopen' => array(
        'description' => 'Grastin REST API access',
        'strict'      => false,
        'value'       => 1,
    ),
);
